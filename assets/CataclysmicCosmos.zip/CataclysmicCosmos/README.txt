      -- CATACLYSMIC COSMOS --
A Computer Game Designed and Developed By:
Robert Lockyer and Andrew Carter
----------------------------------------
Note: top_scores.txt should be in the
same directory as the .jar file for the
game to work properly
----------------------------------------
Feel free to share this game, but we
would appreciate credit and a link back
to our sites. Please include this file 
with the game when you share it. Thanks, 
have fun! 

All source code is copyright Andrew 
Carter and Robert Lockyer and is not 
authorized for redistribution.
----------------------------------------
Robert Lockyer: www.RobLockyer.Com
Andrew Carter:  Currently No Site
----------------------------------------
Feedback is welcome. if we get time
and constructive feedback we may try to
improve the game. Send feedback to: 
RobertLockyer@Gmail.Com